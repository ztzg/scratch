/* Copyright 2006 The FreeRADIUS server project */

#ifndef _OTHER_H
#define _OTHER_H

RCSIDH(other_h, "$Id: 2a02dcb0ced0c4b2d842cab4cf66791db2460d4b $")

/* define the function */

void other_function(void);

#endif /*_OTHER_H*/
